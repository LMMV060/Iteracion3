package es.tuespiral.spring.cliente;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.tuespiral.spring.cliente.*;

@RestController
@RequestMapping("clientes")
public class ClienteController {
	
	@Autowired
	private ClienteService cli;

	
	
	@GetMapping
	public ResponseEntity<Iterable<Cliente>> findAll() {	
		return new ResponseEntity<>(cli.findAll(), HttpStatus.OK);
		
	}
	
	
	@GetMapping("/{NIF}")
	public ResponseEntity<Cliente> findByNIF(@PathVariable String NIF) throws ClienteNotFoundException {
		return new ResponseEntity<>(cli.findByNIF(NIF), HttpStatus.OK);
		
		
	}
	
	
	@GetMapping("/cliente")
	public ResponseEntity<Cliente> findByIdWithParam(@RequestParam String NIF) throws ClienteNotFoundException {
		return findByNIF(NIF);
	}
	
	
	@PostMapping
	public ResponseEntity<Cliente> create(@RequestBody Cliente p) throws ClienteException {
		Cliente cliente = cli.createCliente(p.getNombre(), p.getNIF());
		return new ResponseEntity<>(cliente, HttpStatus.CREATED);
	}
	
	
	@PutMapping
	public ResponseEntity<Cliente> update(@RequestBody Cliente p) throws ClienteException {
		Cliente cliente = cli.updateCliente(p.getId(), p.getNombre(), p.getNIF());
		return new ResponseEntity<>(cliente, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/{NIF}")
	public ResponseEntity<Void> delete(@PathVariable String NIF) throws ClienteException  {
		cli.deleteCliente(NIF);
		
		return new ResponseEntity<>(HttpStatus.OK);
	}
	

	
	
}
