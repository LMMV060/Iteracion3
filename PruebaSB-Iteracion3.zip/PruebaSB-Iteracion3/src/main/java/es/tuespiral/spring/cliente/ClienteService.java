package es.tuespiral.spring.cliente;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.NonNull;

@Service
public class ClienteService {
	@Autowired
	private ClienteRepository repo;

	public Iterable<Cliente> findAll() {
		return repo.findAll();
	}
	
	public Cliente createCliente(@NonNull String name, @NonNull String NIF) throws ClienteException {
		Cliente p = new Cliente(name, NIF);
		repo.save(p);
		return p;
	}

	public Cliente updateCliente(@NonNull Long id, @NonNull String name, @NonNull String NIF) throws ClienteException {
		Optional<Cliente> op = repo.findById(id); 
		
		if (op.isEmpty()) {
			throw new ClienteNotFoundException("El producto con ID = " + id + " no existe");
		} else {
			Cliente p = op.get();
			p.setNombre(name);
			p.setNIF(NIF);
			repo.save(p);
			return p;
		}
	}
	
	public void deleteCliente(@NonNull String NIF) throws ClienteException {
		Optional<Cliente> op = repo.findByNIF(NIF) ;
		
		if (op.isEmpty()) {
			throw new ClienteNotFoundException("El cliente con NIF = " + NIF + " no existe");
		} else {
			Cliente p = op.get();
			repo.delete(p);
		}
	}

	public Cliente findById(Long id) throws ClienteNotFoundException {
		Optional<Cliente> op = repo.findById(id); 
		
		if (op.isEmpty()) {
			throw new ClienteNotFoundException("El cliente con ID = " + id + " no existe");
		} else {
			Cliente p = op.get();
			System.out.println(p);
			return p;
		}
	}
	
	public Cliente findByNIF(String NIF) throws ClienteNotFoundException{
		
		Optional<Cliente> op = repo.findByNIF(NIF);
		
		if (op.isEmpty()) {
			throw new ClienteNotFoundException("El cliente con NIF = " + NIF + " no existe");
		} else {
			Cliente p = op.get();
			System.out.println(p);
			return p;
		}
	}
	
	
}
