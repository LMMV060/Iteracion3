insert into Clientes (Nombre, NIF) values ('Luis Miguel', '49826060X');
insert into Clientes (Nombre, NIF) values ('Pedro', 'AAAbfs');
insert into Clientes (Nombre, NIF) values ('Marta', '12345678A');

